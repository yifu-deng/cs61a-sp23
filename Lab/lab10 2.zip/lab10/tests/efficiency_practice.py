test = {
  'name': 'efficiency_practice',
  'points': 0,
  'suites': [
    {
      'cases': [
        {
          'answer': '8e8c7a23b9c775ff5a3cc44717606c74',
          'choices': [
            'Constant',
            'Logarithmic',
            'Linear',
            'Quadratic',
            'Exponential',
            'None of these'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'The count_partitions function runs in ____ time in the length of its input.'
        },
        {
          'answer': '38e7263fbec047dafe64d91f71f10ed4',
          'choices': [
            'Constant',
            'Logarithmic',
            'Linear',
            'Quadratic',
            'Exponential',
            'None of these'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'The is_palindrome function runs in ____ time in the length of its input.'
        },
        {
          'answer': '16fa3c5d90de695437f338aa27b1291d',
          'choices': [
            'Constant',
            'Logarithmic',
            'Linear',
            'Quadratic',
            'Exponential',
            'None of these'
          ],
          'hidden': False,
          'locked': True,
          'multiline': False,
          'question': 'The binary_search function runs in ____ time in the length of its input.'
        }
      ],
      'scored': False,
      'type': 'concept'
    }
  ]
}
